local active = {} 

local function debugPrint(...)
    if Config.Debug then
        print('[eks_custody_alarm]', ...)
    end
end

local byId = {}
CreateThread(function()
    for _, s in ipairs(Config.Stations or {}) do
        local act, deact = {}, {}
        for i, p in ipairs(s.ActivatePoints or {}) do act[i] = p end
        for i, p in ipairs(s.DeactivatePoints or {}) do deact[i] = p end
        byId[s.id] = { label = s.label, ActivatePoints = act, DeactivatePoints = deact }
    end
end)

local function nowDate()
    return os.date((Config.UseUTC and '!' or '') .. '%Y-%m-%d')
end
local function nowTime()
    return os.date((Config.UseUTC and '!' or '') .. '%H:%M:%S')
end

local function collectIds(src)
    local ids = { license='n/a', steam='n/a', discord='n/a', fivem='n/a', ip='n/a' }
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:find('license:') == 1 then ids.license = id end
        if id:find('steam:')   == 1 then ids.steam   = id end
        if id:find('discord:') == 1 then ids.discord = id end
        if id:find('fivem:')   == 1 then ids.fivem   = id end
        if id:find('ip:')      == 1 then ids.ip      = id end
    end
    return ids
end

local function sendEmbed(title, description, fields, color)
    local url = Config.Webhook
    if not url or url == '' or url == 'REPLACE_WITH_YOUR_WEBHOOK_URL' then
        debugPrint('Discord webhook missing/blank. Set Config.Webhook in config.lua')
        return
    end

    local payload = {
        username = 'Custody Alarm',
        embeds = {{
            title = title,
            description = description,
            color = color or 16711680,
            fields = fields,
            footer = { text = 'Custody Alarm - ' .. (Config.UseUTC and 'UTC' or 'Local Time') },
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ') -- ISO UTC for Discord
        }}
    }

    if Config.Debug then
        debugPrint('Posting Discord webhook...')
    end

    PerformHttpRequest(url, function(statusCode, body, headers)
        if Config.Debug then
            debugPrint(('Discord webhook response: %s'):format(statusCode or 'nil'))
            if not statusCode or statusCode < 200 or statusCode >= 300 then
                debugPrint('Response body: ' .. (body or 'nil'))
            end
        end
    end, 'POST', json.encode(payload), { ['Content-Type'] = 'application/json' })
end

RegisterNetEvent('eks_custody_alarm:activate', function(stationId, pointIndex)
    local src = source
    local station = byId[stationId]
    if not station then
        TriggerClientEvent('eks_custody_alarm:client:alert', src, 'Invalid station.', 'error'); return
    end
    if active[stationId] then
        TriggerClientEvent('eks_custody_alarm:client:alert', src, 'Alarm is already active at this station.', 'error'); return
    end

    local pt = station.ActivatePoints[pointIndex]
    if not pt then
        TriggerClientEvent('eks_custody_alarm:client:alert', src, 'Invalid activation point.', 'error'); return
    end

    active[stationId] = {
        coords = pt.coords,
        pointName = pt.name,
        stationLabel = station.label,
        activatedBy = src,
        startedAt = os.time()
    }

    TriggerClientEvent('eks_custody_alarm:client:notifyActivate', -1, station.label, pt.name, pt.coords)

    TriggerClientEvent('eks_custody_alarm:client:activate', -1, stationId, station.label, pt.name, pt.coords)

    local name = GetPlayerName(src) or ('ID %s'):format(src)
    local desc = ('Station: **%s**'):format(station.label)
    local fields = {
        { name = 'Activated By', value = name, inline = true },
        { name = 'Date', value = nowDate(), inline = true },
        { name = 'Time', value = nowTime(), inline = true },
        { name = 'Area', value = pt.name, inline = true },
    }
    sendEmbed('Custody Alarm Activated', desc, fields, 16711680) -- red
end)

RegisterNetEvent('eks_custody_alarm:deactivate', function(stationId)
    local src = source
    local station = byId[stationId]
    if not station then
        TriggerClientEvent('eks_custody_alarm:client:alert', src, 'Invalid station.', 'error'); return
    end
    if not active[stationId] then
        TriggerClientEvent('eks_custody_alarm:client:alert', src, 'No active alarm at this station.', 'error'); return
    end

    local data = active[stationId]
    active[stationId] = nil

    TriggerClientEvent('eks_custody_alarm:client:deactivate', -1, stationId, station.label)

    if Config.SendDeactivationEmbed then
        local name = GetPlayerName(src) or ('ID %s'):format(src)
        local desc = ('Station: **%s**'):format(station.label)
        local fields = {
            { name = 'Deactivated By', value = name, inline = true },
            { name = 'Date', value = nowDate(), inline = true },
            { name = 'Time', value = nowTime(), inline = true },
            { name = 'Area', value = (data and data.pointName) or 'Unknown', inline = true },
        }
        sendEmbed('Custody Alarm Cleared', desc, fields, 65280) -- green
    end
end)

lib.callback.register('eks_custody_alarm:getStates', function(_)
    return active
end)

RegisterCommand('custodyalarm_testwebhook', function(src)
    local desc = 'Webhook connectivity test from eks_custody_alarm.'
    local fields = {
        { name = 'Date', value = nowDate(), inline = true },
        { name = 'Time', value = nowTime(), inline = true },
    }
    sendEmbed('Custody Alarm - Webhook Test', desc, fields, 3447003)
    if src and src > 0 then
        TriggerClientEvent('eks_custody_alarm:client:alert', src, 'Sent test webhook (check Discord).')
    else
        debugPrint('Sent webhook test (console).')
    end
end, true)
