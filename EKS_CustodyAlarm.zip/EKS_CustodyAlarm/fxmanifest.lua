fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'EKS Custody Alarm'
author 'Cowby - Echo Kilo Studios'
description 'Configurable custody alarm with ox_target, ox_lib notifications, and Discord embeds.'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/script.js',
    'html/style.css',
    'html/panicstrip.ogg' 
}

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

dependencies {
    'ox_lib',
    'ox_target'
}
