local stations = Config.Stations
local activeStations = {}   
local zones = {}            
local shouldPlay = false
local audioPlaying = false

local function debugPrint(...)
    if Config.Debug then
        print('[eks_custody_alarm]', ...)
    end
end

CreateThread(function()
    Wait(250)
    for _, station in ipairs(stations) do
        for pIndex, pt in ipairs(station.ActivatePoints or {}) do
            local id = exports.ox_target:addSphereZone({
                coords = pt.coords,
                radius = pt.radius or 1.2,
                debug = Config.Debug,
                options = {
                    {
                        name = ('eks_custody_alarm:activate:%s:%d'):format(station.id, pIndex),
                        icon = 'fa-solid fa-bell',
                        label = 'Activate Alarm',  -- short, no location revealed
                        distance = 1.6,
                        canInteract = function(_, distance)
                            return distance <= (pt.radius or 1.2) + 0.2 and not activeStations[station.id]
                        end,
                        onSelect = function()
                            TriggerServerEvent('eks_custody_alarm:activate', station.id, pIndex)
                        end
                    }
                }
            })
            zones[#zones+1] = id
        end

        for pIndex, pt in ipairs(station.DeactivatePoints or {}) do
            local id = exports.ox_target:addSphereZone({
                coords = pt.coords,
                radius = pt.radius or 1.2,
                debug = Config.Debug,
                options = {
                    {
                        name = ('eks_custody_alarm:deactivate:%s:%d'):format(station.id, pIndex),
                        icon = 'fa-solid fa-bell-slash',
                        label = 'Turn Off Alarm',  -- short label
                        distance = 1.6,
                        canInteract = function(_, distance)
                            return distance <= (pt.radius or 1.2) + 0.2 and activeStations[station.id]
                        end,
                        onSelect = function()
                            TriggerServerEvent('eks_custody_alarm:deactivate', station.id)
                        end
                    }
                }
            })
            zones[#zones+1] = id
        end
    end

    local state = lib.callback.await('eks_custody_alarm:getStates', false)
    if state and type(state) == 'table' then
        activeStations = state
    end
end)

local function nuiPlay()
    if audioPlaying then return end
    audioPlaying = true
    SendNUIMessage({
        action = 'play',
        file = Config.Alarm.SoundFile,
        volume = Config.Alarm.Volume,
        loop = Config.Alarm.Loop
    })
end

local function nuiStop()
    if not audioPlaying then return end
    audioPlaying = false
    SendNUIMessage({ action = 'stop' })
end

CreateThread(function()
    while true do
        local wait = 500
        if next(activeStations) ~= nil then
            local ped = PlayerPedId()
            local myCoords = GetEntityCoords(ped)
            local near = false

            for _, data in pairs(activeStations) do
                if #(myCoords - data.coords) <= (Config.Alarm.SoundRadius or 30.0) then
                    near = true
                    break
                end
            end

            if near and not shouldPlay then
                shouldPlay = true
                nuiPlay()
            elseif (not near) and shouldPlay then
                shouldPlay = false
                nuiStop()
            end

            wait = 250
        else
            if shouldPlay then
                shouldPlay = false
                nuiStop()
            end
        end
        Wait(wait)
    end
end)

RegisterNetEvent('eks_custody_alarm:client:notifyActivate', function(stationLabel, pointName, coords)
    local ped = PlayerPedId()
    local myCoords = GetEntityCoords(ped)
    if #(myCoords - coords) <= (Config.Alarm.NotifyRadius or 60.0) then
        -- Use an ASCII hyphen to avoid the   diamonds some fonts show for unicode
        lib.notify({
            title = 'Alarm Activated',
            description = (stationLabel or 'Custody') .. ' - ' .. (pointName or 'Unknown'),
            type = 'inform',
            -- omit icon to avoid the big red/green symbols; some ox_lib builds still show a neutral dot
            duration = Config.Alarm.NotifyDuration or 8000
        })
    end
end)

RegisterNetEvent('eks_custody_alarm:client:activate', function(stationId, stationLabel, pointName, coords)
    activeStations[stationId] = { coords = coords, pointName = pointName, stationLabel = stationLabel }
end)

RegisterNetEvent('eks_custody_alarm:client:deactivate', function(stationId, stationLabel)
    activeStations[stationId] = nil
    lib.notify({
        title = 'Alarm Cleared',
        description = stationLabel or 'Custody',
        type = 'inform',
        duration = 4000
    })
end)

RegisterNetEvent('eks_custody_alarm:client:alert', function(msg, style)
    lib.notify({
        title = 'Custody Alarm',
        description = tostring(msg or 'Info'),
        type = (style == 'error' and 'error') or 'inform',
        duration = 4000
    })
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, id in ipairs(zones) do
        exports.ox_target:removeZone(id)
    end
    nuiStop()
end)
