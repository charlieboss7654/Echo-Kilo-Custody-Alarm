Config = {}

-- General
Config.Debug = false

-- Discord webhook for embeds
Config.Webhook = 'https://discord.com/api/webhooks/1413553804351373332/_Z_i7NlnaT9KRt5iC2lPVWUVwSgmoC0LI8iuH4PY6Ilc1zz8hpD-RdslzVoQiMdeIESJ'

-- Time formatting for embeds (server real time)
-- UseUTC = true forces UTC; if false, uses server local time.

Config.UseUTC = false
Config.TimeFormat = '%Y-%m-%d %H:%M:%S'  -- 2025-09-05 13:45:10

-- Alarm behavior
Config.Alarm = {
    SoundFile = 'panicstrip.ogg', -- located in html/
    Volume = 0.6,                 -- 0.0 - 1.0
    Loop = true,
    SoundRadius = 30.0,           -- players within this distance hear the alarm
    NotifyRadius = 60.0,          -- players within this distance get ox_lib notify
    NotifyDuration = 8000         -- ms
}

-- Optional: send an embed when the alarm is turned off

Config.SendDeactivationEmbed = true

-- Stations and points
-- You can add as many stations/points as you like.
-- Each activation point needs a unique 'name' for display (e.g., "Cells").
-- radius is the ox_target sphere radius for interaction.

Config.Stations = {
    {
        id = 'missionrow',
        label = 'Mission Row Custody',
        ActivatePoints = {
            { name = 'Cells', coords = vec3(459.78, -992.08, 24.91), radius = 1.2 },
            { name = 'Charge Desk', coords = vec3(441.35, -978.65, 30.69), radius = 1.2 },
        },
        DeactivatePoints = {
            { name = 'Sergeant Panel', coords = vec3(460.39, -988.75, 24.91), radius = 1.2 },
        }
    },
    --[[ Example extra station
    {
        id = 'sandy',
        label = 'Sandy Shores Custody',
        ActivatePoints = {
            { name = 'Cells', coords = vec3(1854.5, 3687.3, 34.27), radius = 1.2 },
        },
        DeactivatePoints = {
            { name = 'Front Desk Panel', coords = vec3(1851.8, 3689.1, 34.27), radius = 1.2 },
        }
    }
    ]]
}
