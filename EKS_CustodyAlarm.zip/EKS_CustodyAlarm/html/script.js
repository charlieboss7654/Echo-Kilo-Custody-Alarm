const audio = document.getElementById('alarmAudio');

window.addEventListener('message', (e) => {
  const data = e.data || {};
  if (data.action === 'play') {
    audio.src = data.file || 'panicstrip.ogg';
    audio.loop = !!data.loop;
    audio.volume = typeof data.volume === 'number' ? data.volume : 0.6;

    const p = audio.play();
    if (p && typeof p.catch === 'function') p.catch(() => {});
  }

  if (data.action === 'stop') {
    audio.pause();
    audio.currentTime = 0;
  }
});
